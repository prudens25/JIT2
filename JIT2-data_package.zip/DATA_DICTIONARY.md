# Data Dictionary

Conditions: `D1` returns all dependencies added by a commit. `B1` applies a graph rule. `E1` retains all visible path-closing edges. `E2` ranks visible path-closing edges. `B2` through `B5` are increasing external-model evidence conditions.

`trigger_f1` is the harmonic mean of trigger-edge precision and recall against the hidden differential oracle. `trigger_exact` is one when the predicted and oracle trigger sets match exactly. `mean_candidates` is the mean number of returned candidate edges. `witness_target_hit` is the proportion of events where a selected target reaches at least one oracle witness region. `uer` is the unsupported-entity rate. `q_value` is the Benjamini-Hochberg adjusted value.

`events` is the number of evaluated contexts. `repos` is the number of repositories represented by those contexts. `precision`, `recall`, and `f1` in noncycle results refer to topology-specific root-edge targets. `target_hit` refers to topology-specific target coverage.

The external-model data are reported by execution route because the API and web collections cover different repository subsets. They are compared only within a route.
